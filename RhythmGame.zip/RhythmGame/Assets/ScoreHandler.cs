﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreHandler : MonoBehaviour
{
    private float score;
    public Text scoreText;

    // Start is called before the first frame update
    void Start()
    {
        score = MyGlobalScore.SharedInstance.score;
    }

    // Update is called once per frame
    void Update()
    {
        score = MyGlobalScore.SharedInstance.score;
        scoreText.text = "Score: " + score;
    }
}
