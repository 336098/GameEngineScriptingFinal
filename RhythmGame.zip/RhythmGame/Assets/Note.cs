﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Note : MonoBehaviour
{
    private float speed = 10f;
    private float scoreAmount = 100;
    public KeyCode code;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        transform.Translate(Vector3.right * speed * Time.deltaTime);
        if (this.transform.position.x > 5)
        {
            Destroy(this.gameObject);
        }

        if (this.transform.position.x < 1 && this.transform.position.x > -1 && Input.GetKeyDown(code))
        {
            float hitScore = Mathf.Abs(this.transform.position.x) * 100;
            scoreAmount -= hitScore;
            scoreAmount = Mathf.Round(scoreAmount * 100f) / 100f;

            MyGlobalScore.SharedInstance.score += scoreAmount;
            //Debug.Log(scoreAmount);
            Destroy(this.gameObject);
        }
    }
}

//Score is held globally in a singleton in order to transfer to other scripts
public class MyGlobalScore
{
    private static MyGlobalScore instance = null;
    public static MyGlobalScore SharedInstance
    {
        get
        {
            if (instance == null)
            {
                instance = new MyGlobalScore();
            }
            return instance;
        }
    }

    public float score = 0;
}
